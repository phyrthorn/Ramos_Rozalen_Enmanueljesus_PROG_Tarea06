/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alquilervehiculos.mvc.modelo;

import alquilervehiculos.mvc.modelo.dao.Alquileres;
import alquilervehiculos.mvc.modelo.dao.Clientes;
import alquilervehiculos.mvc.modelo.dao.Vehiculos;
import alquilervehiculos.mvc.modelo.dominio.Alquiler;
import alquilervehiculos.mvc.modelo.dominio.Cliente;
import alquilervehiculos.mvc.modelo.dominio.DireccionPostal;
import alquilervehiculos.mvc.modelo.dominio.vehiculo.Autobus;
import alquilervehiculos.mvc.modelo.dominio.vehiculo.Turismo;
import alquilervehiculos.mvc.modelo.dominio.vehiculo.Vehiculo;

    /**
     *
     * @author Enmanuel jesus
     */
public class ModeloAlquilerVehiculos implements IModeloAlquilerVehiculos {

    private Vehiculos vehiculos;
    private Clientes clientes;
    private Alquileres alquileres;

    //Constructor    
    
    public ModeloAlquilerVehiculos() {
        vehiculos = new Vehiculos();
        clientes = new Clientes();
        alquileres = new Alquileres();
    }

    @Override
    public void insertarCliente(Cliente cliente) {
        clientes.insertar(cliente);
    }

    @Override
    public void borrarCliente(String dni) {
        clientes.borrar(dni);
    }

    @Override
    public Cliente buscarCliente(String dni) {
        return clientes.buscar(dni);
    }

    @Override
    public Cliente[] obtenerClientes() {
        return clientes.getClientes();
    }

    @Override
    public void insertarVehiculo(Vehiculo vehiculo) {
        vehiculos.insertar(vehiculo);
    }

    @Override
    public void borrarVehiculo(String matricula) {
        vehiculos.borrar(matricula);
    }

    @Override
    public Vehiculo buscarVehiculo(String matricula) {
        return vehiculos.buscar(matricula);
    }

    @Override
    public Vehiculo[] obtenerVehiculos() {
        return vehiculos.getVehiculos();
    }

    @Override
    public void abrirAlquiler(Cliente cliente, Vehiculo vehiculo) {
        alquileres.abrir(cliente, vehiculo);
    }

    @Override
    public void cerrarAlquiler(Vehiculo vehiculo) {
        alquileres.cerrar(vehiculo);
    }

    @Override
    public Alquiler[] obtenerAlquileres() {
        return alquileres.getAlquileres();
    }

    @Override
    public void insertarDatosPrueba() {
        Cliente cliente0 = new Cliente("r", "12345688R", new DireccionPostal("r", "r", "12345"));
        Cliente cliente1 = new Cliente("w", "21457869W", new DireccionPostal("w", "w", "98745"));

        Vehiculo turismo0 = new Turismo("1234TTT", "r", "r", 150, 5, 5);
        Vehiculo turismo1 = new Autobus("9874CCC", "w", "w", 500, 100, 300);

        insertarCliente(cliente0);
        insertarCliente(cliente1);

        insertarVehiculo(turismo0);
        insertarVehiculo(turismo1);
        
        abrirAlquiler(cliente0, turismo0);
        abrirAlquiler(cliente1, turismo1);
        
    }
}
